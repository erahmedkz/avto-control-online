import { ReactNode, useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { ThemeToggle } from "./ThemeToggle";
import { 
  Home, 
  User, 
  LogOut, 
  Car, 
  Map, 
  Settings, 
  Bell,
  Menu,
  X,
  Activity,
  Key,
  LocateFixed
} from "lucide-react";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";
import { toast } from "sonner";

type LayoutProps = {
  children: ReactNode;
};

export function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, signOut, loading } = useAuth();
  const isMobile = useIsMobile();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifications, setNotifications] = useState<{ count: number; hasUnread: boolean }>({ count: 0, hasUnread: false });
  
  // Close sidebar on route change
  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);

  // Check authentication
  useEffect(() => {
    const protectedRoutes = ["/dashboard", "/profile", "/vehicles", "/control", "/settings", "/map"];
    const isProtectedRoute = protectedRoutes.some(route => location.pathname.startsWith(route));
    
    if (isProtectedRoute && !user) {
      navigate("/login");
    }
  }, [location, user, navigate]);

  // Функция для получения количества уведомлений
  const fetchNotificationCount = async () => {
    if (!user) return;
    
    try {
      // Для демонстрации используем локальные имитированные данные
      // вместо запроса к несуществующей таблице
      const randomCount = Math.floor(Math.random() * 5) + 1;
      
      setNotifications({
        count: randomCount,
        hasUnread: randomCount > 0
      });
    } catch (error) {
      console.error("Error handling notifications:", error);
      // В случае ошибки используем безопасные значения по умолчанию
      setNotifications({
        count: 0,
        hasUnread: false
      });
    }
  };
  
  // Вызываем при монтировании компонента
  useEffect(() => {
    if (user) {
      fetchNotificationCount();
      
      // Устанавливаем интервал для периодического обновления
      const interval = setInterval(fetchNotificationCount, 30000); // Каждые 30 секунд
      
      return () => clearInterval(interval);
    }
  }, [user, location.pathname]);

  const handleSignOut = async () => {
    try {
      await signOut();
      toast.success("Вы успешно вышли из системы");
    } catch (error) {
      console.error("Error signing out:", error);
      toast.error("Ошибка при выходе из системы");
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col">
        <div className="flex flex-1">
          <div className="flex flex-1 flex-col">
            <main className="flex-1 p-6">
              <div className="flex justify-center items-center h-[80vh]">
                <div className="flex flex-col items-center">
                  <div className="animate-spin h-12 w-12 border-4 border-primary border-opacity-30 border-t-primary rounded-full mb-4"></div>
                  <p className="text-gray-500 dark:text-gray-400">Загрузка данных...</p>
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>
    );
  }
  
  if (!user) {
    return (
      <div className="flex min-h-screen flex-col">
        <div className="flex flex-1">
          <div className="flex flex-1 flex-col">
            <main className="flex-1 p-6">
              <div className="flex justify-center items-center h-[80vh]">
                <div className="text-center">
                  <h2 className="text-2xl font-bold mb-4">Необходима авторизация</h2>
                  <p className="mb-6">Пожалуйста, войдите в систему для доступа к этой странице</p>
                  <Link to="/login">
                    <Button>Войти в систему</Button>
                  </Link>
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      {/* Mobile button for opening/closing sidebar */}
      {user && isMobile && (
        <button 
          className={`fixed z-50 top-4 ${sidebarOpen ? 'left-[280px]' : 'left-4'} p-2 rounded-full bg-white dark:bg-gray-800 shadow-md transition-all duration-300 hover:bg-gray-100 dark:hover:bg-gray-700`}
          onClick={() => setSidebarOpen(!sidebarOpen)}
          aria-label={sidebarOpen ? "Закрыть меню" : "Открыть меню"}
        >
          {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      )}
      
      {/* Sidebar navigation - only for authorized users */}
      {user && (
        <nav 
          className={`fixed md:sticky top-0 z-40 h-screen transition-all duration-300 ease-in-out ${
            isMobile 
              ? sidebarOpen ? 'left-0' : '-left-[280px]' 
              : 'left-0'
          } w-[280px] md:w-64 bg-white dark:bg-gray-800 shadow-lg flex flex-col`}
        >
          <div className="px-6 py-8 flex flex-col h-full overflow-y-auto">
            <div className="flex items-center justify-between">
              <Link to="/dashboard" className="flex items-center">
                <h2 className="text-xl font-bold bg-gradient-to-r from-blue-500 to-purple-600 bg-clip-text text-transparent">
                  АвтоКонтроль
                </h2>
                <Car className="text-blue-500 dark:text-blue-400 ml-2" size={24} />
              </Link>
            </div>
            
            <div className="mt-8 px-2">
              <h3 className="text-xs uppercase tracking-wider font-semibold text-gray-500 dark:text-gray-400 mb-2">
                Главное меню
              </h3>
            </div>
            
            <ul className="space-y-1 flex-1">
              <NavItem 
                to="/dashboard" 
                icon={<Home size={20} />} 
                label="Главная панель" 
                active={location.pathname === "/dashboard"} 
              />
              <NavItem 
                to="/vehicles" 
                icon={<Car size={20} />} 
                label="Мои автомобили" 
                active={location.pathname.startsWith("/vehicles") && !location.pathname.includes("/control")} 
              />
              
              <div className="mt-6 px-2">
                <h3 className="text-xs uppercase tracking-wider font-semibold text-gray-500 dark:text-gray-400 mb-2">
                  Управление
                </h3>
              </div>
              
              <NavItem 
                to="/control" 
                icon={<Key size={20} />} 
                label="Удаленное управление" 
                active={location.pathname.startsWith("/control")} 
              />
              <NavItem 
                to="/map" 
                icon={<LocateFixed size={20} />} 
                label="Геолокация" 
                active={location.pathname === "/map"} 
              />
              <NavItem 
                to="/settings" 
                icon={<Bell size={20} />} 
                label="Уведомления" 
                active={location.pathname === "/settings"} 
              />
              
              <div className="mt-6 px-2">
                <h3 className="text-xs uppercase tracking-wider font-semibold text-gray-500 dark:text-gray-400 mb-2">
                  Личное
                </h3>
              </div>
              
              <NavItem 
                to="/profile" 
                icon={<User size={20} />} 
                label="Мой профиль" 
                active={location.pathname === "/profile"} 
              />
            </ul>
            
            <div className="mt-auto pt-4">
              <Button 
                onClick={handleSignOut}
                variant="outline"
                className="flex items-center w-full justify-start gap-2 py-2 text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
              >
                <LogOut size={20} />
                <span>Выйти</span>
              </Button>
            </div>
          </div>
        </nav>
      )}
      
      {/* Main content */}
      <div className="flex-1 transition-all duration-300">
        {/* Only show header for authenticated users */}
        {user && (
          <header className="bg-white dark:bg-gray-800 shadow-sm py-4 px-6 flex justify-between items-center sticky top-0 z-10">
            <h1 className="text-xl font-semibold text-gray-800 dark:text-white ml-12 md:ml-0">
              {getPageTitle(location.pathname)}
            </h1>
            <div className="flex items-center space-x-4">
              <Link to="/settings" className="relative p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 transition-colors" onClick={(e) => {
                // При клике показываем тестовое уведомление
                e.preventDefault();
                toast.success('Новое уведомление', {
                  description: 'У вас есть непрочитанные уведомления',
                  action: {
                    label: 'Посмотреть',
                    onClick: () => navigate('/settings')
                  }
                });
              }}>
                <Bell size={18} />
                {notifications.hasUnread && (
                  <span className="absolute top-0 right-0 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
                    {notifications.count > 9 ? "9+" : notifications.count}
                  </span>
                )}
              </Link>
              <ThemeToggle />
            </div>
          </header>
        )}
        
        <main className="p-4 md:p-6 animate-fade-in overflow-x-hidden">
          {children}
        </main>
      </div>
    </div>
  );
}

interface NavItemProps {
  to: string;
  icon: ReactNode;
  label: string;
  active: boolean;
}

function NavItem({ to, icon, label, active }: NavItemProps) {
  return (
    <li>
      <Link
        to={to}
        className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-200 ${
          active 
            ? "bg-blue-50 text-blue-600 dark:bg-gray-700 dark:text-blue-400" 
            : "text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 hover:text-blue-500 dark:hover:text-blue-400"
        }`}
      >
        <span>{icon}</span>
        <span>{label}</span>
      </Link>
    </li>
  );
}

function getPageTitle(pathname: string): string {
  switch (true) {
    case pathname === "/dashboard":
      return "Панель управления";
    case pathname.startsWith("/vehicles") && !pathname.includes("/control"):
      return "Мои автомобили";
    case pathname.startsWith("/control"):
      return "Удаленное управление";
    case pathname === "/map":
      return "Геолокация и маршруты";
    case pathname === "/profile":
      return "Мой профиль";
    case pathname === "/settings":
      return "Уведомления и оповещения";
    default:
      return "АвтоКонтроль";
  }
}
