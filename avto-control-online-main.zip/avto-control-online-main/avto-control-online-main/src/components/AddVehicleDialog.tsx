import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, ImageIcon } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Массив изображений автомобилей для выбора
const carImages = [
  "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?q=80&w=1000&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1503376780353-7e6692767b70?q=80&w=1000&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1542362567-b07e54358753?q=80&w=1000&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1550355291-bbee04a92027?q=80&w=1000&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?q=80&w=1000&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?q=80&w=1000&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1580273916550-e323be2ae537?q=80&w=1000&auto=format&fit=crop",
];

const vehicleFormSchema = z.object({
  name: z.string().min(2, "Название должно содержать минимум 2 символа"),
  model: z.string().min(2, "Модель должна содержать минимум 2 символа"),
  year: z.coerce.number().min(1900, "Год должен быть не менее 1900").max(new Date().getFullYear() + 1, `Год не может быть больше ${new Date().getFullYear() + 1}`),
  color: z.string().optional(),
  licensePlate: z.string().min(1, "Укажите государственный номер"),
  imageUrl: z.string().min(1, "Выберите изображение автомобиля"),
});

type VehicleFormValues = z.infer<typeof vehicleFormSchema>;

interface AddVehicleDialogProps {
  onVehicleAdded: () => void;
}

export function AddVehicleDialog({ onVehicleAdded }: AddVehicleDialogProps) {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  const form = useForm<VehicleFormValues>({
    resolver: zodResolver(vehicleFormSchema),
    defaultValues: {
      name: "",
      model: "",
      year: new Date().getFullYear(),
      color: "",
      licensePlate: "",
      imageUrl: carImages[0],
    },
    mode: "onChange",
  });

  async function onSubmit(data: VehicleFormValues) {
    if (!user) {
      toast.error("Необходимо войти в систему");
      return;
    }

    setIsSubmitting(true);
    try {
      // Проверка соединения с базой данных
      try {
        const { error: pingError } = await supabase.from("vehicles").select("count").limit(1);
        if (pingError) {
          throw new Error("Ошибка соединения с базой данных");
        }
      } catch (err) {
        console.error("Connection error:", err);
        toast.error("Ошибка соединения с сервером", {
          description: "Проверьте подключение к интернету"
        });
        setIsSubmitting(false);
        return;
      }

      // Попытка добавления автомобиля
      try {
        const { error } = await supabase.from("vehicles").insert({
          name: data.name,
          model: data.model,
          year: data.year,
          color: data.color || "",
          status: "Parked",
          user_id: user.id
        });

        if (error) throw error;

        // После успешного добавления автомобиля, сохраним выбранное изображение и номер
        // в localStorage для использования на клиенте
        try {
          // Получаем только что добавленный автомобиль, чтобы узнать его ID
          const { data: newVehicle, error: fetchError } = await supabase
            .from("vehicles")
            .select("id")
            .eq("user_id", user.id)
            .eq("name", data.name)
            .eq("model", data.model)
            .order('created_at', { ascending: false })
            .limit(1)
            .single();
          
          if (fetchError || !newVehicle) {
            console.error("Error fetching new vehicle:", fetchError);
          } else {
            // Сохраняем URL изображения в localStorage
            const imageKey = `vehicle_image_${newVehicle.id}`;
            localStorage.setItem(imageKey, data.imageUrl);
            
            // Сохраняем номер в localStorage
            const licensePlateKey = `vehicle_license_${newVehicle.id}`;
            localStorage.setItem(licensePlateKey, data.licensePlate);
          }
        } catch (error) {
          console.error("Error saving image reference:", error);
        }

        toast.success("Автомобиль успешно добавлен");
        form.reset();
        setOpen(false);
        onVehicleAdded();
      } catch (error: any) {
        console.error("Insert error:", error);
        toast.error("Ошибка при добавлении автомобиля", {
          description: error.message || "Проверьте правильность заполнения полей"
        });
      }
    } catch (error: any) {
      console.error("Error adding vehicle:", error);
      toast.error("Не удалось добавить автомобиль", {
        description: "Пожалуйста, попробуйте еще раз"
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  // Обновление изображения при выборе
  const handleImageChange = (index: number) => {
    setSelectedImageIndex(index);
    form.setValue("imageUrl", carImages[index]);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus size={18} />
          Добавить автомобиль
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] max-h-[85vh] overflow-y-auto flex flex-col">
        <DialogHeader className="sticky top-0 bg-background z-10 pt-4 pb-2">
          <DialogTitle>Добавить новый автомобиль</DialogTitle>
          <DialogDescription>
            Заполните форму для добавления нового автомобиля в систему.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pb-24 flex-1">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Название</FormLabel>
                  <FormControl>
                    <Input placeholder="Моя машина" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="model"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Модель</FormLabel>
                  <FormControl>
                    <Input placeholder="Toyota Camry" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="year"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Год выпуска</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1900}
                      max={new Date().getFullYear() + 1}
                      placeholder="2023"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="color"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Цвет</FormLabel>
                  <FormControl>
                    <Input placeholder="Белый" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="licensePlate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Государственный номер *</FormLabel>
                  <FormControl>
                    <Input placeholder="А123БВ77" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="imageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Изображение автомобиля</FormLabel>
                  <div className="space-y-3">
                    <div className="grid grid-cols-4 gap-2">
                      {carImages.map((image, index) => (
                        <div 
                          key={index} 
                          className={`relative cursor-pointer h-16 rounded-md overflow-hidden border-2 ${index === selectedImageIndex ? 'border-primary' : 'border-transparent'}`}
                          onClick={() => handleImageChange(index)}
                        >
                          <img 
                            src={image} 
                            alt={`Автомобиль ${index+1}`} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ))}
                    </div>
                    <div className="h-32 rounded-md overflow-hidden border border-input">
                      <img 
                        src={carImages[selectedImageIndex]} 
                        alt="Предпросмотр" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <FormControl>
                      <Input type="hidden" {...field} />
                    </FormControl>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </form>
        </Form>
        <div className="sticky bottom-0 left-0 right-0 bg-background border-t p-4 mt-auto shadow-md dark:border-gray-700 z-10">
          <div className="flex space-x-2 w-full max-w-[90%] mx-auto">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              className="flex-1"
            >
              Отмена
            </Button>
            <Button 
              type="submit"
              onClick={() => {
                const formElement = document.querySelector('form');
                if (formElement) formElement.requestSubmit();
              }}
              disabled={isSubmitting}
              className="flex-1"
            >
              {isSubmitting ? (
                <div className="flex items-center justify-center">
                  <div className="h-4 w-4 border-2 border-white border-opacity-25 border-t-white rounded-full animate-spin mr-2"></div>
                  <span>Добавление...</span>
                </div>
              ) : "Добавить"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
