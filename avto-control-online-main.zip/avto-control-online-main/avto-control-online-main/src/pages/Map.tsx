import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Car, Search, LocateFixed, Plus, Trash2, Edit2, Check, X } from "lucide-react";
import { toast } from "sonner";
import { Layout } from "@/components/Layout";
import { Link } from "react-router-dom";

interface Vehicle {
  id: string;
  name: string;
  model: string;
  location: string | null;
}

interface LocationPoint {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  type: "vehicle" | "favorite" | "marker";
  color?: string;
}

const Map = () => {
  const { user } = useAuth();
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [locationPoints, setLocationPoints] = useState<LocationPoint[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [newLocationName, setNewLocationName] = useState("");
  const [currentPosition, setCurrentPosition] = useState<{lat: number; lng: number} | null>(null);
  const [editingPoint, setEditingPoint] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const mapRef = useRef<any>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<Record<string, any>>({});

  // Подключаем Leaflet CSS из CDN
  useEffect(() => {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    link.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
    link.crossOrigin = '';
    document.head.appendChild(link);
    
    // Добавляем скрипт для Leaflet
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    script.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
    script.crossOrigin = '';
    document.head.appendChild(script);
    
    return () => {
      document.head.removeChild(link);
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, []);

  useEffect(() => {
    if (!user) return;
    
    const fetchVehicles = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from("vehicles")
          .select("id, name, model, location")
          .eq("user_id", user.id);
        
        if (error) throw error;
        
        setVehicles(data || []);
        
        // Generate stable location points for vehicles
        const stablePoints: LocationPoint[] = (data || []).map((vehicle) => {
          // Используем ID автомобиля для стабильной геолокации
          const seed = vehicle.id.split('-')[0].charCodeAt(0);
          const latOffset = (seed % 100) / 1000;
          const lngOffset = ((seed * 2) % 100) / 1000;
          
          return {
          id: vehicle.id,
          name: vehicle.name,
            latitude: 55.751244 + latOffset, // Москва как базовая точка
            longitude: 37.618423 + lngOffset,
            type: "vehicle",
            color: "#3b82f6" // Синий цвет для автомобилей
          };
        });
        
        // Добавим несколько предопределенных локаций
        const favoriteLocations: LocationPoint[] = [
          {
            id: "fav-1",
            name: "Дом",
            latitude: 55.7558,
            longitude: 37.6173,
            type: "favorite",
            color: "#ef4444" // Красный
          },
          {
            id: "fav-2",
            name: "Работа",
            latitude: 55.7439,
            longitude: 37.5630,
            type: "favorite",
            color: "#10b981" // Зелёный
          }
        ];
        
        // Получим сохраненные маркеры из localStorage
        let savedMarkers: LocationPoint[] = [];
        try {
          const saved = localStorage.getItem('mapMarkers');
          if (saved) {
            savedMarkers = JSON.parse(saved);
          }
        } catch (e) {
          console.error("Ошибка загрузки сохраненных маркеров:", e);
        }
        
        setLocationPoints([...stablePoints, ...favoriteLocations, ...savedMarkers]);
      } catch (error: any) {
        console.error("Ошибка при загрузке данных:", error);
        toast.error("Не удалось загрузить данные для карты");
      } finally {
        setLoading(false);
      }
    };
    
    fetchVehicles();
    
    // Get current user location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentPosition({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          // Default to Moscow
          setCurrentPosition({ lat: 55.751244, lng: 37.618423 });
        }
      );
    } else {
      // Default to Moscow if geolocation is not supported
      setCurrentPosition({ lat: 55.751244, lng: 37.618423 });
    }
  }, [user]);

  // Функция добавления маркера на карту
  const addMarkerToMap = (point: LocationPoint) => {
    if (!mapInstanceRef.current || !window.L) return;
    
    const L = window.L;
    
    // Создаем иконку
    const icon = L.divIcon({
      className: 'custom-marker',
      html: `<div style="
        background-color: ${point.color || '#3b82f6'}; 
        width: 24px; 
        height: 24px; 
        border-radius: 50%; 
        display: flex; 
        align-items: center; 
        justify-content: center;
        color: white;
        font-size: 12px;
        box-shadow: 0 0 0 2px white, 0 0 10px rgba(0,0,0,0.3);
      ">
        ${getMarkerIcon(point.type)}
      </div>`,
      iconSize: [24, 24],
      iconAnchor: [12, 12]
    });
    
    // Создаем маркер
    const marker = L.marker([point.latitude, point.longitude], {
      icon: icon,
      draggable: point.type === 'marker'
    }).addTo(mapInstanceRef.current);
    
    // Добавляем попап
    marker.bindPopup(`
      <div>
        <strong>${point.name}</strong>
        <br/>
        ${point.type === 'vehicle' 
          ? `<a href="/control/${point.id}" style="color: blue;">Управление</a>` 
          : ''}
      </div>
    `);
    
    // Если это пользовательский маркер, добавляем возможность перетаскивания
    if (point.type === 'marker') {
      marker.on('dragend', (e: any) => {
        const latlng = e.target.getLatLng();
        updateMarkerPosition(point.id, latlng.lat, latlng.lng);
      });
    }
    
    // Сохраняем маркер для будущего использования
    markersRef.current[point.id] = marker;
  };
  
  // Функция для обновления позиции маркера
  const updateMarkerPosition = (id: string, lat: number, lng: number) => {
    setLocationPoints(prev => {
      const updated = prev.map(p => 
        p.id === id ? { ...p, latitude: lat, longitude: lng } : p
      );
      
      // Сохраняем только пользовательские маркеры
      saveUserMarkers(updated);
      
      return updated;
    });
    
    toast.success("Позиция маркера обновлена");
  };
  
  // Сохранение пользовательских маркеров в localStorage
  const saveUserMarkers = (points: LocationPoint[]) => {
    const userMarkers = points.filter(p => p.type === 'marker');
    localStorage.setItem('mapMarkers', JSON.stringify(userMarkers));
  };
  
  // Функция получения иконки маркера
  const getMarkerIcon = (type: string) => {
    switch (type) {
      case 'vehicle':
        return '🚗';
      case 'favorite':
        return '⭐';
      default:
        return '📍';
    }
  };

  // Добавление новой локации
  const addLocation = () => {
    if (!newLocationName) {
      toast.error("Введите название локации");
      return;
    }
    
    toast.info("Кликните на карту, чтобы добавить локацию");
  };

  // Инициализация карты после загрузки Leaflet
  useEffect(() => {
    if (!mapRef.current || !currentPosition || typeof window.L === 'undefined') return;

    // Если карта уже инициализирована, не создаем новую
    if (mapInstanceRef.current) return;
    
    const loadMap = () => {
      // Проверяем, загружен ли Leaflet
      if (typeof window.L !== 'undefined') {
        // Создаем карту
        const map = window.L.map(mapRef.current).setView(
          [currentPosition.lat, currentPosition.lng], 
          13
        );

        // Добавляем бесплатный тайл-сервер OpenStreetMap
        window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        mapInstanceRef.current = map;
        
        // Слушатель клика по карте для добавления новых маркеров
        map.on('click', function(e: any) {
          if (newLocationName.trim()) {
            const newMarker: LocationPoint = {
      id: `marker-${Date.now()}`,
      name: newLocationName,
              latitude: e.latlng.lat,
              longitude: e.latlng.lng,
              type: "marker",
              color: "#8b5cf6" // Фиолетовый для пользовательских маркеров
            };
            
            addMarkerToMap(newMarker);
            
            setLocationPoints(prev => {
              const updated = [...prev, newMarker];
              // Сохраняем только пользовательские маркеры
              saveUserMarkers(updated);
              return updated;
            });
            
            setNewLocationName("");
            toast.success("Новая локация добавлена");
          }
        });
      } else {
        // Если Leaflet еще не загружен, пробуем снова через 100 мс
        setTimeout(loadMap, 100);
      }
    };
    
    loadMap();

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [mapRef.current, currentPosition, newLocationName]);

  // Добавляем маркеры на карту
  useEffect(() => {
    if (!mapInstanceRef.current || !locationPoints.length || typeof window.L === 'undefined') return;
    
    // Очищаем все существующие маркеры
    Object.values(markersRef.current).forEach((marker: any) => {
      marker.remove();
    });
    
    markersRef.current = {};
    
    // Добавляем новые маркеры
    locationPoints.forEach(point => {
      addMarkerToMap(point);
    });
    
    // Центрируем карту, чтобы видеть все маркеры
    if (locationPoints.length > 0) {
      const bounds = Object.values(markersRef.current).map((marker: any) => 
        marker.getLatLng()
      );
      
      if (bounds.length) {
        mapInstanceRef.current.fitBounds(bounds);
      }
    }
  }, [locationPoints, mapInstanceRef.current]);
  
  // Удаление локации
  const deleteLocation = (id: string) => {
    if (markersRef.current[id]) {
      markersRef.current[id].remove();
      delete markersRef.current[id];
    }
    
    setLocationPoints(prev => {
      const updated = prev.filter(p => p.id !== id);
      saveUserMarkers(updated);
      return updated;
    });
    
    toast.success("Локация удалена");
  };
  
  // Начало редактирования имени локации
  const startEditLocation = (id: string, name: string) => {
    setEditingPoint(id);
    setEditName(name);
  };
  
  // Сохранение отредактированного имени
  const saveEditLocation = (id: string) => {
    if (!editName.trim()) {
      toast.error("Имя локации не может быть пустым");
      return;
    }
    
    setLocationPoints(prev => {
      const updated = prev.map(p => 
        p.id === id ? { ...p, name: editName } : p
      );
      saveUserMarkers(updated);
      return updated;
    });
    
    setEditingPoint(null);
    setEditName("");
    
    // Обновляем попап
    if (markersRef.current[id]) {
      const popup = markersRef.current[id].getPopup();
      if (popup) {
        const point = locationPoints.find(p => p.id === id);
        if (point) {
          popup.setContent(`
            <div>
              <strong>${editName}</strong>
              <br/>
              ${point.type === 'vehicle' 
                ? `<a href="/control/${point.id}" style="color: blue;">Управление</a>` 
                : ''}
            </div>
          `);
        }
      }
    }
    
    toast.success("Имя локации обновлено");
  };
  
  // Отмена редактирования
  const cancelEditLocation = () => {
    setEditingPoint(null);
    setEditName("");
  };

  // Фильтрация локаций по поисковому запросу
  const filteredLocations = locationPoints.filter(point => 
    point.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Layout>
      <div className="container mx-auto space-y-6">
        <div className="mb-4">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">
            Карта геолокаций
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Отслеживайте местоположение ваших автомобилей и управляйте собственными локациями
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Sidebar with controls */}
        <div className="md:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <Search className="mr-2 h-5 w-5 text-blue-500" />
                  Поиск и управление
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Найти место или автомобиль..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                
                  <div className="space-y-1 max-h-60 overflow-y-auto">
                  {filteredLocations.length > 0 ? (
                    filteredLocations.map((point) => (
                      <div 
                        key={point.id}
                          className="flex items-center justify-between p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md"
                        >
                          <div 
                            className="flex items-center cursor-pointer"
                        onClick={() => {
                              if (mapInstanceRef.current && markersRef.current[point.id]) {
                                mapInstanceRef.current.setView(
                                  [point.latitude, point.longitude], 
                                  15
                                );
                                markersRef.current[point.id].openPopup();
                              }
                            }}
                          >
                            <div 
                              className="h-5 w-5 rounded-full flex items-center justify-center mr-2 text-xs"
                              style={{ backgroundColor: point.color || '#3b82f6', color: 'white' }}
                            >
                              {getMarkerIcon(point.type)}
                            </div>
                            
                            {editingPoint === point.id ? (
                              <div className="flex items-center">
                                <Input
                                  value={editName}
                                  onChange={(e) => setEditName(e.target.value)}
                                  size={20}
                                  className="h-7 py-1 text-sm"
                                  autoFocus
                                />
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  className="h-7 w-7 p-0 ml-1"
                                  onClick={() => saveEditLocation(point.id)}
                                >
                                  <Check className="h-4 w-4 text-green-500" />
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  className="h-7 w-7 p-0"
                                  onClick={cancelEditLocation}
                                >
                                  <X className="h-4 w-4 text-red-500" />
                                </Button>
                              </div>
                            ) : (
                              <span>{point.name}</span>
                            )}
                          </div>
                          
                          {point.type === 'marker' && !editingPoint && (
                            <div className="flex space-x-1">
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                className="h-7 w-7 p-0"
                                onClick={() => startEditLocation(point.id, point.name)}
                              >
                                <Edit2 className="h-4 w-4 text-blue-500" />
                              </Button>
                              
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                className="h-7 w-7 p-0"
                                onClick={() => deleteLocation(point.id)}
                              >
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          )}
                          
                          {point.type === 'vehicle' && !editingPoint && (
                            <Link to={`/control/${point.id}`}>
                              <Button size="sm" variant="outline" className="h-7 py-0 px-2 text-xs">
                                Управление
                              </Button>
                            </Link>
                          )}
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-2">
                      Нет результатов
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                  <Plus className="mr-2 h-5 w-5 text-blue-500" />
                Добавить локацию
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Input
                    placeholder="Название новой локации"
                  value={newLocationName}
                  onChange={(e) => setNewLocationName(e.target.value)}
                />
                  
                  <Button onClick={addLocation} className="w-full">
                    <LocateFixed className="mr-2 h-4 w-4" />
                    Добавить на карту
                </Button>
                  
                  <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
                    После ввода названия нажмите кнопку и кликните на карту, чтобы добавить локацию.
                    Добавленные локации можно перетаскивать.
                  </p>
                </div>
            </CardContent>
          </Card>
        </div>
        
          {/* Map Container */}
        <div className="md:col-span-3">
            <Card className="overflow-hidden">
              <div 
                ref={mapRef} 
                className="h-[600px] w-full"
              ></div>
          </Card>
        </div>
      </div>
    </div>
    </Layout>
  );
};

// Добавляем расширение типов для Window
declare global {
  interface Window {
    L: any;
  }
}

export default Map;
