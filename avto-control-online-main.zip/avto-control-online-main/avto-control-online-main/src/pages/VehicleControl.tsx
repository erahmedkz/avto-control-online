import { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { 
  Card, 
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { 
  Lock, 
  Unlock, 
  Power, 
  PowerOff, 
  Thermometer, 
  Fan, 
  Radio, 
  ArrowUp, 
  ArrowDown,
  Headphones,
  Fuel,
  Battery,
  PlusCircle,
  AlertTriangle,
  Wrench,
  Key,
  LucideIcon,
  Music,
  Lightbulb,
  Settings,
  Shield,
  Map,
  Navigation,
  Compass,
  Tv,
  Share,
  Phone,
  WindIcon,
  ChevronUp,
  ChevronDown,
  DoorOpen,
  Sun,
  Moon,
  PartyPopper,
  Umbrella,
  Snowflake,
  ParkingSquare
} from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";

// Интерфейс для данных из базы Supabase
interface VehicleData {
  id: string;
  name: string;
  model: string;
  year: number;
  color: string | null;
  created_at: string | null;
  last_updated: string | null;
  location: string | null;
  status: string | null;
  user_id: string;
  license_plate: string | null;
  image_url: string | null;
}

interface Vehicle {
  id: string;
  name: string;
  model: string;
  make?: string;
  year: number;
  color?: string;
  status?: string;
  licensePlate?: string;
  batteryLevel?: number;
  fuelLevel?: number;
  mileage?: number;
  lastService?: {
    date: string;
    type: string;
  };
  image?: string;
  location?: string;
}

interface FeatureCardProps {
  icon: LucideIcon;
  color: string;
  title: string;
  description: string;
  children: React.ReactNode;
  disabled?: boolean;
}

function FeatureCard({ icon: Icon, color, title, description, children, disabled }: FeatureCardProps) {
  return (
    <Card className={`overflow-hidden transition-all duration-300 ${disabled ? 'opacity-60' : 'hover:shadow-md'}`}>
      <div className={`h-2 bg-${color}-500 w-full`}></div>
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <Icon className={`h-5 w-5 text-${color}-500`} />
          <CardTitle className="text-lg">{title}</CardTitle>
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {children}
      </CardContent>
    </Card>
  );
}

const VehicleControl = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [vehicle, setVehicle] = useState<Vehicle | null>(null);
  const [loading, setLoading] = useState(true);
  const [isLocked, setIsLocked] = useState(true);
  const [isEngineOn, setIsEngineOn] = useState(false);
  const [temperature, setTemperature] = useState(22);
  const [fanSpeed, setFanSpeed] = useState(1);
  const [volume, setVolume] = useState(5);
  const [resourceTimer, setResourceTimer] = useState<number | null>(null);
  const [activeNotifications, setActiveNotifications] = useState<{
    battery?: boolean;
    fuel?: boolean;
    maintenance?: boolean;
    tire?: boolean;
  }>({});
  
  // Дополнительные состояния для новых функций
  const [headlights, setHeadlights] = useState(false);
  const [interiorLights, setInteriorLights] = useState(false);
  const [windowsOpen, setWindowsOpen] = useState(false);
  const [musicPlaying, setMusicPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState("Случайный трек");
  const [sunroof, setSunroof] = useState(false);
  const [parkingMode, setParkingMode] = useState(false);
  const [currentTab, setCurrentTab] = useState("main");
  const [seatPosition, setSeatPosition] = useState(5);
  const [defrost, setDefrost] = useState(false);
  const [doors, setDoors] = useState<Record<string, boolean>>({
    frontLeft: true,
    frontRight: true,
    rearLeft: true,
    rearRight: true,
    trunk: true,
  });
  
  // Новые состояния для дополнительных функций
  const [windows, setWindows] = useState<Record<string, boolean>>({
    frontLeft: true,
    frontRight: true,
    rearLeft: true,
    rearRight: true,
    sunroof: true,
  });
  const [lights, setLights] = useState({
    headlights: false,
    hazard: false,
    interior: false,
    ambient: false
  });
  const [trunk, setTrunk] = useState(false);
  const [alarm, setAlarm] = useState(false);
  const [fuelFlap, setFuelFlap] = useState(false);
  const [chargingPort, setChargingPort] = useState(false);
  const [remotePreheat, setRemotePreheat] = useState(false);
  const [remoteCooling, setRemoteCooling] = useState(false);
  const [valet, setValet] = useState(false);
  const [childLock, setChildLock] = useState(false);
  const [geoFencing, setGeoFencing] = useState(false);
  const [speedLimit, setSpeedLimit] = useState(0);
  const [navigationDestination, setNavigationDestination] = useState("");
  
  // Функция для постепенного уменьшения ресурсов
  const decreaseResources = useCallback(() => {
    if (!vehicle) return;
    
    setVehicle(prev => {
      if (!prev) return prev;
      
      // Уменьшаем заряд батареи и уровень топлива на небольшое значение
      const newBatteryLevel = Math.max(0, (prev.batteryLevel || 0) - 0.5);
      const newFuelLevel = Math.max(0, (prev.fuelLevel || 0) - 0.2);
      
      return {
        ...prev,
        batteryLevel: newBatteryLevel,
        fuelLevel: newFuelLevel
      };
    });
  }, [vehicle]);

  // Установка таймера для уменьшения ресурсов
  useEffect(() => {
    if (vehicle) {
      // Очищаем предыдущий таймер, если он был
      if (resourceTimer) {
        clearInterval(resourceTimer);
      }
      
      // Создаем новый таймер, который вызывает функцию каждую минуту
      const timer = window.setInterval(decreaseResources, 60000);
      setResourceTimer(timer);
      
      return () => {
        if (resourceTimer) {
          clearInterval(resourceTimer);
        }
      };
    }
  }, [vehicle, decreaseResources, resourceTimer]);
  
  useEffect(() => {
    if (!user) return;
    
    const fetchVehicle = async () => {
      try {
        setLoading(true);
        
        // Проверяем соединение с базой данных
        const { error: pingError } = await supabase.from("vehicles").select("count").limit(1);
        if (pingError) {
          console.error("Database connection error:", pingError);
          toast.error("Ошибка соединения с базой данных", {
            description: "Проверьте интернет-соединение и повторите попытку позже",
            duration: 5000
          });
          setLoading(false);
          return;
        }
        
        let vehicleData;
        
        if (!id) {
          // Если id не указан, получаем первый автомобиль пользователя
          const { data, error } = await supabase
            .from("vehicles")
            .select("*")
            .eq("user_id", user.id)
            .order('created_at', { ascending: false })
            .limit(1);
          
          if (error) {
            console.error("Error fetching vehicles:", error);
            toast.error("Не удалось загрузить список автомобилей", {
              description: "Проверьте соединение и повторите попытку",
              duration: 5000
            });
            setLoading(false);
            return;
          }
          
          if (!data || data.length === 0) {
            // Если у пользователя нет автомобилей, перенаправляем на страницу списка
            toast.info("У вас нет автомобилей", {
              description: "Добавьте автомобиль для управления им",
              duration: 5000
            });
            navigate("/vehicles");
            return;
          }
          
          vehicleData = data[0] as VehicleData;
        } else {
          // Если id указан, получаем конкретный автомобиль
          const { data, error } = await supabase
            .from("vehicles")
            .select("*")
            .eq("id", id)
            .eq("user_id", user.id)
            .single();
          
          if (error) {
            console.error("Error fetching vehicle:", error);
            toast.error("Не удалось загрузить данные автомобиля", {
              description: "Проверьте идентификатор автомобиля или ваши права доступа",
              duration: 5000
            });
            navigate("/vehicles");
            return;
          }
          
          vehicleData = data as VehicleData;
        }
        
        // Генерируем стабильные данные на основе id автомобиля
        const seed = vehicleData.id.split('-')[0].charCodeAt(0); // Используем первый символ id как seed
        const batteryLevel = 60 + (seed % 35); // От 60% до 95%
        const fuelLevel = 50 + (seed % 45); // От 50% до 95%
        const mileage = 10000 + (seed * 500); // Базовый пробег
        
        // Определение активных уведомлений на основе данных
        if (batteryLevel < 30) {
          setActiveNotifications(prev => ({ ...prev, battery: true }));
        }
        
        if (fuelLevel < 20) {
          setActiveNotifications(prev => ({ ...prev, fuel: true }));
        }
        
        // Случайные проблемы с шинами и техобслуживанием
        if (seed % 7 === 0) {
          setActiveNotifications(prev => ({ ...prev, maintenance: true }));
        }
        
        if (seed % 5 === 0) {
          setActiveNotifications(prev => ({ ...prev, tire: true }));
        }
        
        // Transform data to match Vehicle interface
        const transformedVehicle: Vehicle = {
          id: vehicleData.id,
          name: vehicleData.name,
          model: vehicleData.model,
          make: vehicleData.model.split(' ')[0],
          year: vehicleData.year,
          color: vehicleData.color || "Не указан",
          status: vehicleData.status || "offline",
          licensePlate: localStorage.getItem(`vehicle_license_${vehicleData.id}`) || "А" + (seed % 999).toString() + "БВ77",
          batteryLevel: batteryLevel,
          fuelLevel: fuelLevel,
          mileage: mileage,
          lastService: {
            date: new Date().toISOString(),
            type: "ТО-1"
          },
          // Используем сохраненное изображение из localStorage или изображение по умолчанию
          image: localStorage.getItem(`vehicle_image_${vehicleData.id}`) || 
                 `https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?q=80&w=1000&auto=format&fit=crop`
        };
        
        setVehicle(transformedVehicle);
      } catch (error) {
        console.error("Error:", error);
        toast.error("Произошла ошибка при загрузке данных", {
          description: "Пожалуйста, обновите страницу или попробуйте позже",
          duration: 5000
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchVehicle();
  }, [id, user, navigate]);
  
  // Функции для пополнения ресурсов
  const refillBattery = () => {
    if (!vehicle) return;
    
    setVehicle(prev => {
      if (!prev) return prev;
      return { ...prev, batteryLevel: 100 };
    });
    
    toast.success('Аккумулятор заряжен', {
      description: 'Аккумулятор заряжен до 100%',
      icon: <Battery className="h-5 w-5 text-green-500" />,
    });
    setActiveNotifications(prev => ({ ...prev, battery: false }));
  };
  
  const refillFuel = () => {
    if (!vehicle) return;
    
    setVehicle(prev => {
      if (!prev) return prev;
      return { ...prev, fuelLevel: 100 };
    });
    
    toast.success('Бак заправлен', {
      description: 'Топливный бак заправлен до 100%',
      icon: <Fuel className="h-5 w-5 text-green-500" />,
    });
    setActiveNotifications(prev => ({ ...prev, fuel: false }));
  };
  
  const handleLockToggle = () => {
    setIsLocked(!isLocked);
    if (!isLocked) {
      toast.error('Автомобиль заблокирован', {
        description: 'Все функции управления недоступны',
        icon: <Lock className="h-5 w-5" />,
      });
    } else {
      toast.success('Автомобиль разблокирован', {
        description: 'Вы можете управлять всеми функциями',
        icon: <Unlock className="h-5 w-5" />,
      });
    }
  };
  
  const handleEngineToggle = () => {
    if (isLocked) {
      toast.error('Ошибка запуска двигателя', {
        description: 'Разблокируйте автомобиль перед запуском двигателя',
        action: {
          label: 'Разблокировать',
          onClick: handleLockToggle
        }
      });
      return;
    }
    
    setIsEngineOn(!isEngineOn);
    if (!isEngineOn) {
      toast.success('Двигатель запущен', {
        description: 'Двигатель успешно запущен и прогревается',
        icon: <Power className="h-5 w-5 text-green-500" />,
      });
    } else {
      toast('Двигатель остановлен', {
        description: 'Двигатель успешно остановлен',
        icon: <PowerOff className="h-5 w-5 text-gray-500" />,
      });
    }
  };
  
  // Функции для решения проблем
  const fixMaintenanceIssue = () => {
    toast.success('Запись на ТО создана', {
      description: 'Ваш автомобиль записан на техническое обслуживание',
      icon: <Wrench className="h-5 w-5 text-blue-500" />,
      duration: 5000,
    });
    setActiveNotifications(prev => ({ ...prev, maintenance: false }));
  };
  
  const fixTireIssue = () => {
    toast.success('Проблема с шинами решена', {
      description: 'Давление в шинах восстановлено до рекомендуемого значения',
      icon: <AlertTriangle className="h-5 w-5 text-green-500" />,
      duration: 5000,
    });
    setActiveNotifications(prev => ({ ...prev, tire: false }));
  };
  
  // Новые функции управления автомобилем
  const toggleWindow = (position: string) => {
    if (isLocked) {
      toast.error('Ошибка управления', {
        description: 'Разблокируйте автомобиль для управления окнами',
      });
      return;
    }
    
    setWindows(prev => {
      const updated = { ...prev, [position]: !prev[position as keyof typeof prev] };
      
      // Уведомление о действии
      if (updated[position as keyof typeof updated]) {
        toast('Окно закрыто', {
          description: `${getWindowName(position)} окно закрыто`,
        });
      } else {
        toast('Окно открыто', {
          description: `${getWindowName(position)} окно открыто`,
        });
      }
      
      return updated;
    });
  };
  
  const toggleAllWindows = (state: boolean) => {
    if (isLocked) {
      toast.error('Ошибка управления', {
        description: 'Разблокируйте автомобиль для управления окнами',
      });
      return;
    }
    
    setWindows({
      frontLeft: state,
      frontRight: state,
      rearLeft: state,
      rearRight: state,
      sunroof: state,
    });
    
    toast(state ? 'Окна закрыты' : 'Окна открыты', {
      description: state ? 'Все окна закрыты' : 'Все окна открыты',
    });
  };
  
  const toggleTrunk = () => {
    if (isLocked) {
      toast.error('Ошибка управления', {
        description: 'Разблокируйте автомобиль для управления багажником',
      });
      return;
    }
    
    setTrunk(prev => !prev);
    toast(!trunk ? 'Багажник открыт' : 'Багажник закрыт', {
      description: !trunk 
        ? 'Багажник успешно открыт' 
        : 'Багажник успешно закрыт',
    });
  };
  
  const toggleHeadlights = () => {
    if (isLocked) {
      toast.error('Ошибка управления', {
        description: 'Разблокируйте автомобиль для управления фарами',
      });
      return;
    }
    
    setLights(prev => ({
      ...prev, 
      headlights: !prev.headlights
    }));
    
    toast.success(!lights.headlights ? 'Фары включены' : 'Фары выключены');
  };
  
  const toggleHazardLights = () => {
    // Аварийную сигнализацию можно включить даже при заблокированной машине
    setLights(prev => ({
      ...prev, 
      hazard: !prev.hazard
    }));
    
    toast.success(!lights.hazard ? 'Аварийная сигнализация включена' : 'Аварийная сигнализация выключена');
  };
  
  const toggleInteriorLights = () => {
    if (isLocked) {
      toast.error('Ошибка управления', {
        description: 'Разблокируйте автомобиль для управления освещением салона',
      });
      return;
    }
    
    setLights(prev => ({
      ...prev, 
      interior: !prev.interior
    }));
    
    toast.success(!lights.interior ? 'Освещение салона включено' : 'Освещение салона выключено');
  };
  
  const toggleAlarm = () => {
    setAlarm(prev => !prev);
    
    if (!alarm) {
      toast.error('Тревога активирована', {
        description: 'Сигнализация автомобиля сработала!',
        duration: 6000,
      });
    } else {
      toast.success('Тревога деактивирована', {
        description: 'Сигнализация автомобиля отключена',
      });
    }
  };
  
  const toggleChildLock = () => {
    setChildLock(prev => !prev);
    
    toast.success(
      !childLock ? 'Детский замок активирован' : 'Детский замок деактивирован', 
      {
        description: !childLock 
          ? 'Задние двери можно открыть только снаружи'
          : 'Задние двери можно открыть изнутри',
      }
    );
  };
  
  const setRemoteClimate = (mode: 'heat' | 'cool' | 'off') => {
    if (mode === 'heat') {
      setRemotePreheat(true);
      setRemoteCooling(false);
      toast.success('Предварительный подогрев запущен', {
        description: 'Температура в салоне будет поддерживаться на уровне 22°C',
      });
    } else if (mode === 'cool') {
      setRemotePreheat(false);
      setRemoteCooling(true);
      toast.success('Предварительное охлаждение запущено', {
        description: 'Температура в салоне будет поддерживаться на уровне 22°C',
      });
    } else {
      setRemotePreheat(false);
      setRemoteCooling(false);
      toast('Климат-контроль выключен', {
        description: 'Дистанционное управление климатом отключено',
      });
    }
  };
  
  const toggleValetMode = () => {
    setValet(prev => !prev);
    
    toast.success(
      !valet ? 'Режим парковщика включен' : 'Режим парковщика выключен',
      {
        description: !valet
          ? 'Ограничен доступ к некоторым функциям и скорости'
          : 'Все функции и ограничения сняты',
      }
    );
  };
  
  const changeSpeedLimit = (value: number) => {
    setSpeedLimit(value);
    
    if (value === 0) {
      toast('Ограничение скорости отключено');
    } else {
      toast.success(`Ограничение скорости установлено на ${value} км/ч`);
    }
  };
  
  const setNavigation = (destination: string) => {
    setNavigationDestination(destination);
    
    if (destination) {
      toast.success(`Навигация установлена на ${destination}`, {
        description: 'Маршрут рассчитан и отправлен в автомобиль',
      });
    } else {
      toast('Навигация отключена');
    }
  };
  
  // Вспомогательная функция для определения названия окна
  const getWindowName = (position: string): string => {
    switch(position) {
      case 'frontLeft': return 'Переднее левое';
      case 'frontRight': return 'Переднее правое';
      case 'rearLeft': return 'Заднее левое';
      case 'rearRight': return 'Заднее правое';
      case 'sunroof': return 'Люк';
      default: return '';
    }
  };
  
  if (loading) {
    return (
      <Layout>
        <div className="flex justify-center items-center h-full py-20">
          <div className="animate-pulse text-gray-400 dark:text-gray-500">
            Загрузка данных автомобиля...
          </div>
        </div>
      </Layout>
    );
  }
  
  if (!vehicle) {
    return (
      <Layout>
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">
            Автомобиль не найден
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            Автомобиль с указанным идентификатором не найден или у вас нет доступа к нему.
          </p>
          <Button onClick={() => navigate("/vehicles")}>
            Вернуться к списку автомобилей
          </Button>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Управление: {vehicle.name}
            </h1>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              {vehicle.make} {vehicle.model}, {vehicle.year}, {vehicle.color}
            </p>
          </div>
          <div className="flex items-center space-x-2 mt-4 md:mt-0">
            <div className={`px-3 py-1 text-sm font-medium rounded-full 
              ${isEngineOn 
                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' 
                : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'}`
            }>
              {isEngineOn ? 'Двигатель запущен' : 'Двигатель остановлен'}
            </div>
            <div className={`px-3 py-1 text-sm font-medium rounded-full 
              ${!isLocked 
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' 
                : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'}`
            }>
              {isLocked ? 'Заблокирован' : 'Разблокирован'}
            </div>
          </div>
        </div>
        
        {/* Активные уведомления */}
        {(activeNotifications.battery || activeNotifications.fuel || 
          activeNotifications.maintenance || activeNotifications.tire) && (
          <Card className="border-orange-500 dark:border-orange-400 border-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center text-orange-600 dark:text-orange-400">
                <AlertTriangle className="mr-2 h-5 w-5" />
                Активные уведомления
              </CardTitle>
              <CardDescription>
                Необходимо решить следующие проблемы
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {activeNotifications.battery && (
                <div className="flex justify-between items-center">
                  <div className="flex items-start">
                    <Battery className="h-5 w-5 text-red-500 mr-2 mt-0.5" />
                    <div>
                      <p className="font-medium">Низкий заряд аккумулятора</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Уровень заряда: {Math.round(vehicle?.batteryLevel || 0)}%
                      </p>
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={refillBattery}
                  >
                    Зарядить
                  </Button>
                </div>
              )}
              
              {activeNotifications.fuel && (
                <div className="flex justify-between items-center">
                  <div className="flex items-start">
                    <Fuel className="h-5 w-5 text-red-500 mr-2 mt-0.5" />
                    <div>
                      <p className="font-medium">Низкий уровень топлива</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Уровень топлива: {Math.round(vehicle?.fuelLevel || 0)}%
                      </p>
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={refillFuel}
                  >
                    Заправить
                  </Button>
                </div>
              )}
              
              {activeNotifications.maintenance && (
                <div className="flex justify-between items-center">
                  <div className="flex items-start">
                    <Wrench className="h-5 w-5 text-yellow-500 mr-2 mt-0.5" />
                    <div>
                      <p className="font-medium">Требуется техническое обслуживание</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Плановое ТО по пробегу
                      </p>
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={fixMaintenanceIssue}
                  >
                    Записаться на ТО
                  </Button>
                </div>
              )}
              
              {activeNotifications.tire && (
                <div className="flex justify-between items-center">
                  <div className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 mt-0.5" />
                    <div>
                      <p className="font-medium">Низкое давление в шинах</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Левая передняя шина: 1.8 бар (рекомендуется 2.2)
                      </p>
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={fixTireIssue}
                  >
                    Накачать шины
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Vehicle Image */}
          <Card className="overflow-hidden">
            <div className="h-48 bg-gradient-to-br from-blue-500 to-violet-600 relative">
              {vehicle?.image ? (
                <img 
                  src={vehicle.image} 
                  alt={vehicle.name} 
                  className="w-full h-full object-cover opacity-70"
                />
              ) : (
                <div className="flex items-center justify-center h-full">
                  <span className="text-white text-4xl">🚗</span>
                </div>
              )}
            </div>
            <CardContent className="p-6">
              <h3 className="text-2xl font-bold mb-2">{vehicle?.name}</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500 dark:text-gray-400">Модель:</span>
                  <span className="font-medium">{vehicle?.model}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500 dark:text-gray-400">Год:</span>
                  <span className="font-medium">{vehicle?.year}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500 dark:text-gray-400">Цвет:</span>
                  <span className="font-medium">{vehicle?.color}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500 dark:text-gray-400">Госномер:</span>
                  <span className="font-medium">{vehicle?.licensePlate}</span>
                </div>
                
                <Separator className="my-3" />
                
                {/* Добавляем индикаторы ресурсов */}
                <div className="space-y-4 mt-4">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <div className="flex items-center">
                        <Battery className="h-4 w-4 mr-1 text-blue-500" />
                        <span className="text-sm font-medium">Аккумулятор</span>
                      </div>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-6 p-0 px-2" 
                        onClick={refillBattery}
                      >
                        <PlusCircle className="h-3 w-3 mr-1" />
                        <span className="text-xs">Зарядить</span>
                      </Button>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                      <div 
                        className={`h-2.5 rounded-full ${
                          (vehicle?.batteryLevel || 0) > 50 
                            ? 'bg-green-500' 
                            : (vehicle?.batteryLevel || 0) > 20 
                            ? 'bg-yellow-500' 
                            : 'bg-red-500'
                        }`} 
                        style={{ width: `${vehicle?.batteryLevel || 0}%` }}
                      ></div>
                    </div>
                    <div className="text-right text-xs mt-1 text-gray-500">
                      {Math.round(vehicle?.batteryLevel || 0)}%
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <div className="flex items-center">
                        <Fuel className="h-4 w-4 mr-1 text-blue-500" />
                        <span className="text-sm font-medium">Топливо</span>
                      </div>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-6 p-0 px-2" 
                        onClick={refillFuel}
                      >
                        <PlusCircle className="h-3 w-3 mr-1" />
                        <span className="text-xs">Заправить</span>
                      </Button>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                      <div 
                        className={`h-2.5 rounded-full ${
                          (vehicle?.fuelLevel || 0) > 50 
                            ? 'bg-green-500' 
                            : (vehicle?.fuelLevel || 0) > 20 
                            ? 'bg-yellow-500' 
                            : 'bg-red-500'
                        }`} 
                        style={{ width: `${vehicle?.fuelLevel || 0}%` }}
                      ></div>
                    </div>
                    <div className="text-right text-xs mt-1 text-gray-500">
                      {Math.round(vehicle?.fuelLevel || 0)}%
                    </div>
                  </div>
                </div>
                
                <div className="mt-4">
                  <Link to={`/vehicles/${vehicle?.id}`}>
                    <Button variant="outline" size="sm" className="w-full">
                      Подробная информация
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Основное управление */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center text-xl">
                <Key className="mr-2 h-5 w-5 text-blue-500" />
                Удаленное управление
              </CardTitle>
              <CardDescription>
                Управляйте основными функциями автомобиля
              </CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Блок блокировки/разблокировки */}
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 flex flex-col items-center justify-center">
                <div className="mb-4 text-center">
                  <div className="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center mx-auto mb-2">
                    {isLocked ? (
                      <Lock className="h-8 w-8 text-red-500 dark:text-red-400" />
                    ) : (
                      <Unlock className="h-8 w-8 text-green-500 dark:text-green-400" />
                    )}
                  </div>
                  <h3 className="font-medium">{isLocked ? 'Заблокирован' : 'Разблокирован'}</h3>
                </div>
              <Button
                variant={isLocked ? "destructive" : "outline"}
                size="lg"
                  className="w-full"
                onClick={handleLockToggle}
              >
                {isLocked ? <Unlock className="mr-2 h-5 w-5" /> : <Lock className="mr-2 h-5 w-5" />}
                {isLocked ? "Разблокировать" : "Заблокировать"}
              </Button>
              </div>
              
              {/* Блок двигателя */}
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 flex flex-col items-center justify-center">
                <div className="mb-4 text-center">
                  <div className="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center mx-auto mb-2">
                    {isEngineOn ? (
                      <Power className="h-8 w-8 text-green-500 dark:text-green-400" />
                    ) : (
                      <PowerOff className="h-8 w-8 text-gray-500 dark:text-gray-400" />
                    )}
                  </div>
                  <h3 className="font-medium">{isEngineOn ? 'Двигатель запущен' : 'Двигатель остановлен'}</h3>
                </div>
              <Button
                variant={isEngineOn ? "destructive" : "default"}
                size="lg"
                  className="w-full"
                onClick={handleEngineToggle}
                disabled={isLocked}
              >
                {isEngineOn ? <PowerOff className="mr-2 h-5 w-5" /> : <Power className="mr-2 h-5 w-5" />}
                  {isEngineOn ? "Остановить двигатель" : "Запустить двигатель"}
              </Button>
              </div>
            </CardContent>
          </Card>
          
          {/* Расширенное управление автомобилем с вкладками */}
          <Card className="lg:col-span-3">
            <CardHeader>
              <CardTitle className="flex items-center text-xl">
                <Settings className="mr-2 h-5 w-5 text-blue-500" />
                Расширенное управление
              </CardTitle>
              <CardDescription>
                Управление различными функциями автомобиля
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="climate" className="space-y-4">
                <TabsList className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 w-full">
                  <TabsTrigger value="climate">
                    <Thermometer className="h-4 w-4 mr-2" />
                    <span>Климат</span>
                  </TabsTrigger>
                  <TabsTrigger value="windows">
                    <div className="h-4 w-4 mr-2">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M0 1a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1zm1 0v14h5V1H1zm13 0a1 1 0 0 0-1-1h-5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1V1zm-1 0v14h-5V1h5z"/>
                      </svg>
                    </div>
                    <span>Окна</span>
                  </TabsTrigger>
                  <TabsTrigger value="lights">
                    <Lightbulb className="h-4 w-4 mr-2" />
                    <span>Освещение</span>
                  </TabsTrigger>
                  <TabsTrigger value="trunk">
                    <DoorOpen className="h-4 w-4 mr-2" />
                    <span>Двери</span>
                  </TabsTrigger>
                  <TabsTrigger value="security">
                    <Shield className="h-4 w-4 mr-2" />
                    <span>Безопасность</span>
                  </TabsTrigger>
                  <TabsTrigger value="nav">
                    <Map className="h-4 w-4 mr-2" />
                    <span>Навигация</span>
                  </TabsTrigger>
                </TabsList>
                
                {/* Вкладка Климат */}
                <TabsContent value="climate" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-5">
                      <h3 className="font-medium text-center mb-6">Температура</h3>
                      <div className="flex flex-col items-center">
                        <div className="text-5xl font-bold text-blue-500 mb-4">{temperature}°C</div>
                        <div className="flex items-center w-full max-w-[200px] justify-between">
                          <Button 
                            variant="outline" 
                            size="icon" 
                            className="rounded-full h-10 w-10"
                            onClick={() => setTemperature(Math.max(16, temperature - 1))}
                            disabled={isLocked}
                          >
                            <ChevronDown className="h-5 w-5" />
                          </Button>
                          <div className="w-32 h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                            <div 
                              className="h-2 bg-blue-500 rounded-full" 
                              style={{ width: `${((temperature - 16) / (30 - 16)) * 100}%` }}
                            ></div>
                          </div>
                          <Button 
                            variant="outline" 
                            size="icon" 
                            className="rounded-full h-10 w-10"
                            onClick={() => setTemperature(Math.min(30, temperature + 1))}
                            disabled={isLocked}
                          >
                            <ChevronUp className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex justify-between mt-4 text-xs text-gray-500 max-w-[200px] mx-auto">
                        <span>16°C</span>
                        <span>30°C</span>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-5">
                      <h3 className="font-medium text-center mb-4">Режим</h3>
                      <div className="grid grid-cols-2 gap-2 mb-4">
                        <Button 
                          variant={remotePreheat ? "default" : "outline"} 
                          className={remotePreheat ? "bg-red-500 hover:bg-red-600" : ""}
                          onClick={() => setRemoteClimate(remotePreheat ? 'off' : 'heat')}
                          disabled={isLocked}
                        >
                          <Thermometer className="h-4 w-4 mr-2" />
                          Подогрев
                        </Button>
                        <Button 
                          variant={remoteCooling ? "default" : "outline"} 
                          className={remoteCooling ? "bg-blue-500 hover:bg-blue-600" : ""}
                          onClick={() => setRemoteClimate(remoteCooling ? 'off' : 'cool')}
                          disabled={isLocked}
                        >
                          <Snowflake className="h-4 w-4 mr-2" />
                          Охлаждение
                        </Button>
                      </div>
                      <h3 className="font-medium mt-6 mb-2">Обдув</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <Label>Скорость</Label>
                          <span className="text-sm font-medium">{fanSpeed}/5</span>
                        </div>
                        <Slider 
                          min={0} 
                          max={5} 
                          step={1} 
                          value={[fanSpeed]} 
                          onValueChange={(values) => setFanSpeed(values[0])}
                          disabled={isLocked}
                        />
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-5">
                      <h3 className="font-medium text-center mb-4">Дополнительно</h3>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <Label htmlFor="defrost">Разморозка</Label>
                          <Switch id="defrost" 
                            checked={defrost} 
                            onCheckedChange={setDefrost}
                            disabled={isLocked} 
                          />
                        </div>
                        <Separator />
                        <div className="flex items-center justify-between">
                          <Label htmlFor="recirculation">Рециркуляция</Label>
                          <Switch id="recirculation" 
                            disabled={isLocked} 
                          />
                        </div>
                        <Separator />
                        <div className="flex items-center justify-between">
                          <Label htmlFor="auto">Авто режим</Label>
                          <Switch id="auto" 
                            disabled={isLocked} 
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                {/* Вкладка Окна */}
                <TabsContent value="windows" className="space-y-4">
                  <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
                    <div className="relative max-w-xl mx-auto h-64">
                      <img src="/car-top-view.svg" alt="Car Top View" className="h-full w-full opacity-20 absolute top-0 left-0" />
                      
                      <div className="absolute top-1/4 left-1/4">
                        <Button 
                          variant={windows.frontLeft ? "default" : "destructive"} 
                          size="sm"
                          className={`h-10 w-10 p-0 rounded-full ${windows.frontLeft ? "bg-green-500 hover:bg-green-600" : ""}`}
                          onClick={() => toggleWindow('frontLeft')}
                          disabled={isLocked}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M1 4.5A2.5 2.5 0 0 1 3.5 2h9A2.5 2.5 0 0 1 15 4.5v1.537c0 .162-.04.327-.128.463l-4.134 5.99c-.379.552-1 .87-1.677.779h-.603A1.94 1.94 0 0 1 6.91 12H5a2 2 0 0 1-2-2V8h-.5A1.5 1.5 0 0 1 1 6.5v-2zm2-1a.5.5 0 0 0-.5.5V6h3V3.5a.5.5 0 0 0-.5-.5h-2zM5 7H2v3a1 1 0 0 0 1 1h2V7zm5.5-4h-4a.5.5 0 0 0-.5.5V6h5V3.5a.5.5 0 0 0-.5-.5zm-2.5 4v4h3a1 1 0 0 0 1-1V7h-4zm7 0h-3v3.5a.5.5 0 0 0 .5.5h2a.5.5 0 0 0 .5-.5V7z"/>
                          </svg>
                        </Button>
                      </div>
                      
                      <div className="absolute top-1/4 right-1/4">
                        <Button 
                          variant={windows.frontRight ? "default" : "destructive"} 
                          size="sm"
                          className={`h-10 w-10 p-0 rounded-full ${windows.frontRight ? "bg-green-500 hover:bg-green-600" : ""}`}
                          onClick={() => toggleWindow('frontRight')}
                          disabled={isLocked}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M1 4.5A2.5 2.5 0 0 1 3.5 2h9A2.5 2.5 0 0 1 15 4.5v1.537c0 .162-.04.327-.128.463l-4.134 5.99c-.379.552-1 .87-1.677.779h-.603A1.94 1.94 0 0 1 6.91 12H5a2 2 0 0 1-2-2V8h-.5A1.5 1.5 0 0 1 1 6.5v-2zm2-1a.5.5 0 0 0-.5.5V6h3V3.5a.5.5 0 0 0-.5-.5h-2zM5 7H2v3a1 1 0 0 0 1 1h2V7zm5.5-4h-4a.5.5 0 0 0-.5.5V6h5V3.5a.5.5 0 0 0-.5-.5zm-2.5 4v4h3a1 1 0 0 0 1-1V7h-4zm7 0h-3v3.5a.5.5 0 0 0 .5.5h2a.5.5 0 0 0 .5-.5V7z"/>
                          </svg>
                        </Button>
                      </div>
                      
                      <div className="absolute bottom-1/3 left-1/4">
                        <Button 
                          variant={windows.rearLeft ? "default" : "destructive"} 
                          size="sm"
                          className={`h-10 w-10 p-0 rounded-full ${windows.rearLeft ? "bg-green-500 hover:bg-green-600" : ""}`}
                          onClick={() => toggleWindow('rearLeft')}
                          disabled={isLocked}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M1 4.5A2.5 2.5 0 0 1 3.5 2h9A2.5 2.5 0 0 1 15 4.5v1.537c0 .162-.04.327-.128.463l-4.134 5.99c-.379.552-1 .87-1.677.779h-.603A1.94 1.94 0 0 1 6.91 12H5a2 2 0 0 1-2-2V8h-.5A1.5 1.5 0 0 1 1 6.5v-2zm2-1a.5.5 0 0 0-.5.5V6h3V3.5a.5.5 0 0 0-.5-.5h-2zM5 7H2v3a1 1 0 0 0 1 1h2V7zm5.5-4h-4a.5.5 0 0 0-.5.5V6h5V3.5a.5.5 0 0 0-.5-.5zm-2.5 4v4h3a1 1 0 0 0 1-1V7h-4zm7 0h-3v3.5a.5.5 0 0 0 .5.5h2a.5.5 0 0 0 .5-.5V7z"/>
                          </svg>
                        </Button>
                      </div>
                      
                      <div className="absolute bottom-1/3 right-1/4">
                        <Button 
                          variant={windows.rearRight ? "default" : "destructive"} 
                          size="sm"
                          className={`h-10 w-10 p-0 rounded-full ${windows.rearRight ? "bg-green-500 hover:bg-green-600" : ""}`}
                          onClick={() => toggleWindow('rearRight')}
                          disabled={isLocked}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M1 4.5A2.5 2.5 0 0 1 3.5 2h9A2.5 2.5 0 0 1 15 4.5v1.537c0 .162-.04.327-.128.463l-4.134 5.99c-.379.552-1 .87-1.677.779h-.603A1.94 1.94 0 0 1 6.91 12H5a2 2 0 0 1-2-2V8h-.5A1.5 1.5 0 0 1 1 6.5v-2zm2-1a.5.5 0 0 0-.5.5V6h3V3.5a.5.5 0 0 0-.5-.5h-2zM5 7H2v3a1 1 0 0 0 1 1h2V7zm5.5-4h-4a.5.5 0 0 0-.5.5V6h5V3.5a.5.5 0 0 0-.5-.5zm-2.5 4v4h3a1 1 0 0 0 1-1V7h-4zm7 0h-3v3.5a.5.5 0 0 0 .5.5h2a.5.5 0 0 0 .5-.5V7z"/>
                          </svg>
                        </Button>
                      </div>
                      
                      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                        <Button 
                          variant={windows.sunroof ? "default" : "destructive"} 
                          size="sm"
                          className={`h-10 w-10 p-0 rounded-full ${windows.sunroof ? "bg-green-500 hover:bg-green-600" : ""}`}
                          onClick={() => toggleWindow('sunroof')}
                          disabled={isLocked}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M14 3a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h12zM2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2z"/>
                            <path d="M4 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zm4-3a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM6 8a1 1 0 0 1 2 0v5a1 1 0 0 1-2 0V8z"/>
                          </svg>
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mt-6">
                      <Button 
                        variant="outline"
                        onClick={() => toggleAllWindows(true)}
                        disabled={isLocked}
                      >
                        Закрыть все окна
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => toggleAllWindows(false)}
                        disabled={isLocked}
                      >
                        Открыть все окна
                      </Button>
                    </div>
                  </div>
                </TabsContent>
                
                {/* Остальные вкладки будут добавлены во втором этапе */}
                
                {/* Вкладка Освещение */}
                <TabsContent value="lights" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
                      <h3 className="font-medium text-center mb-4">Внешнее освещение</h3>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Lightbulb className="h-5 w-5 text-amber-500" />
                            <Label>Фары</Label>
                          </div>
                          <Switch 
                            checked={lights.headlights} 
                            onCheckedChange={() => toggleHeadlights()}
                            disabled={isLocked}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <AlertTriangle className="h-5 w-5 text-red-500" />
                            <Label>Аварийная сигнализация</Label>
                          </div>
                          <Switch 
                            checked={lights.hazard} 
                            onCheckedChange={() => toggleHazardLights()}
                            // Аварийную сигнализацию можно включить даже при заблокированном автомобиле
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <ParkingSquare className="h-5 w-5 text-blue-500" />
                            <Label>Габаритные огни</Label>
                          </div>
                          <Switch disabled={isLocked} />
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between mt-6">
                        <Button 
                          variant="outline" 
                          className="w-full" 
                          onClick={() => {
                            if (!isLocked) {
                              setLights(prev => ({...prev, headlights: true}));
                              toast.success('Все внешние огни включены');
                            } else {
                              toast.error('Разблокируйте автомобиль');
                            }
                          }}
                        >
                          Включить все
                        </Button>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
                      <h3 className="font-medium text-center mb-4">Внутреннее освещение</h3>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Sun className="h-5 w-5 text-amber-500" />
                            <Label>Основной свет</Label>
                          </div>
                          <Switch 
                            checked={lights.interior} 
                            onCheckedChange={() => toggleInteriorLights()}
                            disabled={isLocked}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-violet-500">
                              <path d="M8 2v4"></path>
                              <path d="M16 2v4"></path>
                              <path d="M3 10h18"></path>
                              <path d="M10 14l-2-2"></path>
                              <path d="M12 14h4"></path>
                              <path d="M3 6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6z"></path>
                            </svg>
                            <Label>Подсветка для чтения</Label>
                          </div>
                          <Switch 
                            checked={lights.ambient} 
                            onCheckedChange={() => setLights(prev => ({...prev, ambient: !prev.ambient}))}
                            disabled={isLocked}
                          />
                        </div>
                        
                        <div className="mt-6">
                          <Label>Яркость подсветки салона</Label>
                          <Slider 
                            min={0} 
                            max={100} 
                            step={10}
                            defaultValue={[70]}
                            className="mt-2"
                            disabled={isLocked}
                          />
                          <div className="flex justify-between text-xs text-gray-500 mt-1">
                            <span>Мин</span>
                            <span>Макс</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                {/* Вкладка Двери и багажник */}
                <TabsContent value="trunk" className="space-y-4">
                  <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
                    <div className="relative max-w-xl mx-auto h-64">
                      <img src="/car-top-view.svg" alt="Car Top View" className="h-full w-full opacity-20 absolute top-0 left-0" />
                      
                      <div className="absolute top-1/4 left-1/4">
                        <Button 
                          variant={!trunk ? "default" : "destructive"} 
                          size="sm"
                          className={`h-10 w-10 p-0 rounded-full ${!trunk ? "bg-green-500 hover:bg-green-600" : ""}`}
                          onClick={() => toggleTrunk()}
                          disabled={isLocked}
                        >
                          <DoorOpen className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <div className="absolute top-1/4 right-1/4">
                        <Button 
                          variant={!trunk ? "default" : "destructive"} 
                          size="sm"
                          className={`h-10 w-10 p-0 rounded-full ${!trunk ? "bg-green-500 hover:bg-green-600" : ""}`}
                          onClick={() => toggleTrunk()}
                          disabled={isLocked}
                        >
                          <DoorOpen className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <div className="absolute bottom-1/3 left-1/4">
                        <Button 
                          variant={!trunk ? "default" : "destructive"} 
                          size="sm"
                          className={`h-10 w-10 p-0 rounded-full ${!trunk ? "bg-green-500 hover:bg-green-600" : ""}`}
                          onClick={() => toggleTrunk()}
                          disabled={isLocked}
                        >
                          <DoorOpen className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <div className="absolute bottom-1/3 right-1/4">
                        <Button 
                          variant={!trunk ? "default" : "destructive"} 
                          size="sm"
                          className={`h-10 w-10 p-0 rounded-full ${!trunk ? "bg-green-500 hover:bg-green-600" : ""}`}
                          onClick={() => toggleTrunk()}
                          disabled={isLocked}
                        >
                          <DoorOpen className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <div className="absolute bottom-1/5 left-1/2 transform -translate-x-1/2">
                        <Button 
                          variant={trunk ? "destructive" : "default"} 
                          size="sm"
                          className={`h-10 w-10 p-0 rounded-full ${!trunk ? "bg-green-500 hover:bg-green-600" : "bg-red-500 hover:bg-red-600"}`}
                          onClick={() => toggleTrunk()}
                          disabled={isLocked}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M7 8a1 1 0 0 1 2 0v5a1 1 0 1 1-2 0V8z"/>
                            <path d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5zm-3 0A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V4.5h-2z"/>
                          </svg>
                        </Button>
                      </div>
                    </div>
                    
                    <div className="mt-6 space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <Button 
                          variant="outline"
                          onClick={() => toggleTrunk()}
                          disabled={isLocked}
                        >
                          {trunk ? "Закрыть багажник" : "Открыть багажник"}
                        </Button>
                        <Button 
                          variant="outline"
                          onClick={() => toggleChildLock()}
                        >
                          {childLock ? "Выключить детский замок" : "Включить детский замок"}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg mt-4">
                        <div className="flex items-center">
                          <Fuel className="h-5 w-5 text-blue-500 mr-2" />
                          <Label>Лючок бензобака</Label>
                        </div>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            setFuelFlap(!fuelFlap);
                            toast.success(fuelFlap ? 'Лючок бензобака закрыт' : 'Лючок бензобака открыт');
                          }}
                          disabled={isLocked}
                        >
                          {fuelFlap ? "Закрыть" : "Открыть"}
                        </Button>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
                        <div className="flex items-center">
                          <Battery className="h-5 w-5 text-green-500 mr-2" />
                          <Label>Порт зарядки</Label>
                        </div>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            setChargingPort(!chargingPort);
                            toast.success(chargingPort ? 'Порт зарядки закрыт' : 'Порт зарядки открыт');
                          }}
                          disabled={isLocked}
                        >
                          {chargingPort ? "Закрыть" : "Открыть"}
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                {/* Вкладка Безопасность */}
                <TabsContent value="security" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
                      <h3 className="font-medium text-center mb-4">Безопасность</h3>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <AlertTriangle className="h-5 w-5 text-red-500" />
                            <Label>Тревога</Label>
                          </div>
                          <Switch 
                            checked={alarm} 
                            onCheckedChange={() => toggleAlarm()}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Shield className="h-5 w-5 text-blue-500" />
                            <Label>Режим парковщика</Label>
                          </div>
                          <Switch 
                            checked={valet} 
                            onCheckedChange={() => toggleValetMode()}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Lock className="h-5 w-5 text-green-500" />
                            <Label>Детский замок</Label>
                          </div>
                          <Switch 
                            checked={childLock} 
                            onCheckedChange={() => toggleChildLock()}
                          />
                        </div>
                      </div>
                      
                      <div className="mt-6">
                        <Button 
                          variant="destructive" 
                          className="w-full"
                          onClick={() => {
                            toggleAlarm();
                            toast.error('Режим тревоги активирован!', {
                              description: 'Сигнализация включена, владелец автомобиля уведомлен',
                              duration: 6000,
                            });
                          }}
                        >
                          Активировать режим тревоги
                        </Button>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
                      <h3 className="font-medium text-center mb-4">Ограничения</h3>
                      <div className="space-y-6">
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <Label>Ограничение скорости</Label>
                            <span className="text-sm font-medium">{speedLimit} км/ч</span>
                          </div>
                          <Slider 
                            min={0} 
                            max={150} 
                            step={10}
                            value={[speedLimit]} 
                            onValueChange={(values) => changeSpeedLimit(values[0])}
                          />
                          <div className="flex justify-between text-xs text-gray-500 mt-1">
                            <span>Откл.</span>
                            <span>150 км/ч</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Map className="h-5 w-5 text-blue-500" />
                            <Label>Геозона</Label>
                          </div>
                          <Switch 
                            checked={geoFencing} 
                            onCheckedChange={() => {
                              setGeoFencing(!geoFencing);
                              toast.success(
                                !geoFencing ? 'Геозона активирована' : 'Геозона деактивирована',
                                {
                                  description: !geoFencing
                                    ? 'Вы получите уведомление, если автомобиль покинет зону'
                                    : 'Мониторинг зоны отключен'
                                }
                              );
                            }}
                          />
                        </div>
                        
                        <div className="mt-4">
                          <Button 
                            variant="outline" 
                            className="w-full"
                            onClick={() => {
                              changeSpeedLimit(0);
                              setGeoFencing(false);
                              setValet(false);
                              toast.success('Все ограничения сняты');
                            }}
                          >
                            Сбросить все ограничения
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                {/* Вкладка Навигация */}
                <TabsContent value="nav" className="space-y-4">
                  <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
                    <h3 className="font-medium text-center mb-4">Навигация</h3>
                    <div className="space-y-4">
                      <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                        <h4 className="font-medium mb-2 flex items-center">
                          <Navigation className="h-4 w-4 mr-2 text-blue-500" />
                          Отправить адрес в автомобиль
                        </h4>
                        <div className="grid grid-cols-1 gap-2">
                          <Button 
                            variant="outline" 
                            className="w-full justify-start hover:bg-blue-50 dark:hover:bg-blue-900/20"
                            onClick={() => setNavigation('Дом')}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" className="mr-2">
                              <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h9a1.5 1.5 0 0 0 1.5-1.5V8.207l.646.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5ZM13 7.207V13.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V7.207l5-5 5 5Z"/>
                            </svg>
                            Дом
                          </Button>
                          <Button 
                            variant="outline" 
                            className="w-full justify-start hover:bg-blue-50 dark:hover:bg-blue-900/20"
                            onClick={() => setNavigation('Работа')}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" className="mr-2">
                              <path d="M4 16s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H4Zm4-5.95a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z"/>
                              <path d="M2 1a2 2 0 0 0-2 2v9.5A1.5 1.5 0 0 0 1.5 14h.653a5.373 5.373 0 0 1 1.066-2H1V3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v9h-2.219c.554.654.89 1.373 1.066 2h.653a1.5 1.5 0 0 0 1.5-1.5V3a2 2 0 0 0-2-2H2Z"/>
                            </svg>
                            Работа
                          </Button>
                          <Button 
                            variant="outline" 
                            className="w-full justify-start hover:bg-blue-50 dark:hover:bg-blue-900/20"
                            onClick={() => setNavigation('Супермаркет')}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" className="mr-2">
                              <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
                            </svg>
                            Супермаркет
                          </Button>
                          <Button 
                            variant="outline" 
                            className="w-full justify-start hover:bg-blue-50 dark:hover:bg-blue-900/20"
                            onClick={() => setNavigation('Заправка')}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" className="mr-2">
                              <path d="M3 2.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-.5.5h-5a.5.5 0 0 1-.5-.5v-5Z"/>
                              <path d="M1 2a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v8a2 2 0 0 1 2 2v.5a.5.5 0 0 0 1 0V8h-.5a.5.5 0 0 1-.5-.5V4.375a.5.5 0 0 1 .5-.5h1.495c-.011-.476-.053-.894-.201-1.222a.97.97 0 0 0-.394-.458c-.184-.11-.464-.195-.9-.195a.5.5 0 0 1 0-1c.564 0 1.034.11 1.412.336.383.228.634.551.794.907.295.655.294 1.465.294 2.081v3.175a.5.5 0 0 1-.5.501H15v4.5a1.5 1.5 0 0 1-3 0V12a1 1 0 0 0-1-1v4h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1V2Zm9 0a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v13h8V2Z"/>
                            </svg>
                            Заправка
                          </Button>
                        </div>
                        
                        {navigationDestination && (
                          <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <Map className="h-5 w-5 text-blue-500 mr-2" />
                                <div>
                                  <h5 className="font-medium">Текущий маршрут:</h5>
                                  <p className="text-sm text-gray-500 dark:text-gray-400">{navigationDestination}</p>
                                </div>
                              </div>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                className="h-8 w-8 p-0"
                                onClick={() => {
                                  setNavigationDestination('');
                                  toast('Маршрут отменен');
                                }}
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                                </svg>
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                      
                      <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                        <h4 className="font-medium mb-2 flex items-center">
                          <Compass className="h-4 w-4 mr-2 text-green-500" />
                          Местоположение автомобиля
                        </h4>
                        <div className="h-48 bg-gray-200 dark:bg-gray-700 rounded-lg relative overflow-hidden">
                          <div className="absolute inset-0 flex items-center justify-center">
                            <Button variant="outline" onClick={() => toast.success('Карта загружена', {description: 'Открываем текущее положение автомобиля...'})}>
                              <Map className="h-4 w-4 mr-2" />
                              Открыть карту
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default VehicleControl;
