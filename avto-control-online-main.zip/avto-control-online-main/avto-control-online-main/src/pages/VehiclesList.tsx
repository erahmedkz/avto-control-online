import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { 
  Badge 
} from "@/components/ui/badge";
import { 
  Battery, 
  Fuel, 
  Gauge, 
  Calendar, 
  AlertCircle,
  Car,
  CarFront,
  SlidersHorizontal,
  PlusCircle,
  MapPin,
  Clock,
  ShieldCheck,
  Sparkles,
  Filter,
  Trash2
} from "lucide-react";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { AddVehicleDialog } from "@/components/AddVehicleDialog";
import { Layout } from "@/components/Layout";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

// Интерфейс для данных из базы Supabase
interface VehicleData {
  id: string;
  name: string;
  model: string;
  year: number;
  color: string | null;
  created_at: string | null;
  last_updated: string | null;
  location: string | null;
  status: string | null;
  user_id: string;
  license_plate: string | null;
  image_url: string | null;
}

interface Vehicle {
  id: string;
  name: string;
  model: string;
  make?: string;
  year: number;
  color?: string;
  status?: string;
  licensePlate?: string;
  batteryLevel?: number;
  fuelLevel?: number;
  mileage?: number;
  lastService?: {
    date: string;
    type: string;
  };
  image?: string;
  location?: string;
}

const VehiclesList = () => {
  const { user } = useAuth();
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewType, setViewType] = useState<'grid' | 'list'>('grid');

  const fetchVehicles = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      
      // Проверяем соединение с базой данных
      const { error: pingError } = await supabase.from("vehicles").select("count").limit(1);
      if (pingError) {
        console.error("Database connection error:", pingError);
        toast.error("Ошибка соединения с базой данных", {
          description: "Проверьте интернет-соединение и повторите попытку позже",
          duration: 5000
        });
        setLoading(false);
        return;
      }
      
      const { data, error } = await supabase
        .from("vehicles")
        .select("*")
        .eq("user_id", user.id);
      
      if (error) {
        console.error("Ошибка при загрузке автомобилей:", error);
        toast.error("Не удалось загрузить список автомобилей", {
          description: "Проверьте соединение и повторите попытку",
          duration: 5000
        });
        setLoading(false);
        return;
      }
      
      if (!data || data.length === 0) {
        setVehicles([]);
        setLoading(false);
        return;
      }
      
      const transformedVehicles = (data as VehicleData[]).map(vehicle => {
        // Генерируем стабильные данные на основе id автомобиля
        const seed = vehicle.id.split('-')[0].charCodeAt(0); // Используем первый символ id как seed
        const batteryLevel = 60 + (seed % 35); // От 60% до 95%
        const fuelLevel = 50 + (seed % 45); // От 50% до 95%
        const mileage = 10000 + (seed * 500); // Базовый пробег
        
        // Получаем сохраненное изображение из localStorage
        const imageKey = `vehicle_image_${vehicle.id}`;
        const savedImage = localStorage.getItem(imageKey);
        
        // Получаем сохраненный номер из localStorage
        const licensePlateKey = `vehicle_license_${vehicle.id}`;
        const savedLicensePlate = localStorage.getItem(licensePlateKey);

        return {
          id: vehicle.id,
          name: vehicle.name,
          model: vehicle.model,
          make: vehicle.model.split(' ')[0],
          year: vehicle.year,
          color: vehicle.color || "Не указан",
          status: vehicle.status || "offline",
          licensePlate: savedLicensePlate || "А" + (seed % 999).toString() + "БВ77",
          batteryLevel: batteryLevel,
          fuelLevel: fuelLevel,
          mileage: mileage,
          lastService: {
            date: new Date().toISOString(),
            type: "ТО-1"
          },
          image: savedImage || `https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?q=80&w=1000&auto=format&fit=crop` // Используем изображение по умолчанию
        };
      });
      
      setVehicles(transformedVehicles);
    } catch (error: any) {
      console.error("Ошибка при загрузке автомобилей:", error);
      toast.error("Не удалось загрузить список автомобилей", {
        description: "Произошла непредвиденная ошибка. Пожалуйста, обновите страницу",
        duration: 5000
      });
    } finally {
      setLoading(false);
    }
  };

  // Функция удаления автомобиля
  const deleteVehicle = async (id: string) => {
    if (!user) return;
    
    try {
      setLoading(true);
      
      // Проверяем наличие автомобиля перед удалением
      const { data: checkData, error: checkError } = await supabase
        .from("vehicles")
        .select("id")
        .eq("id", id)
        .eq("user_id", user.id)
        .single();
      
      if (checkError || !checkData) {
        console.error("Error checking vehicle before delete:", checkError);
        toast.error("Автомобиль не найден или у вас нет прав для его удаления");
        setLoading(false);
        return;
      }
      
      const { error } = await supabase
        .from("vehicles")
        .delete()
        .eq("id", id)
        .eq("user_id", user.id);
      
      if (error) {
        console.error("Ошибка при удалении автомобиля:", error);
        toast.error("Не удалось удалить автомобиль", {
          description: "Проверьте соединение и повторите попытку",
          duration: 5000
        });
        setLoading(false);
        return;
      }
      
      toast.success("Автомобиль успешно удален");
      fetchVehicles(); // Обновляем список автомобилей
    } catch (error: any) {
      console.error("Ошибка при удалении автомобиля:", error);
      toast.error("Не удалось удалить автомобиль", {
        description: "Произошла непредвиденная ошибка. Пожалуйста, повторите попытку",
        duration: 5000
      });
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchVehicles();
    }
  }, [user]);

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Шапка страницы с эффектом градиента */}
        <div className="relative mb-8 overflow-hidden bg-gradient-to-r from-blue-600 to-violet-600 rounded-2xl shadow-lg">
          <div className="absolute inset-0 opacity-10 bg-[url('/pattern.svg')] bg-repeat"></div>
          <div className="relative z-10 px-8 py-12 text-white">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-3xl font-bold mb-2">
                  Ваш автопарк
                </h1>
                <p className="text-blue-100 max-w-2xl">
                  Управляйте и мониторьте состояние ваших автомобилей в едином интерфейсе. 
                  Получайте актуальную информацию о каждом транспортном средстве.
                </p>
              </div>
              <div className="mt-6 md:mt-0">
                <div className="flex flex-col sm:flex-row gap-4">
                  <AddVehicleDialog onVehicleAdded={fetchVehicles} />
                  <div className="flex items-center space-x-2 bg-blue-500/30 backdrop-blur-sm rounded-lg p-1">
                    <Button 
                      variant={viewType === 'grid' ? "default" : "ghost"} 
                      size="sm"
                      onClick={() => setViewType('grid')}
                      className="h-9 w-9 p-0 bg-white/10 hover:bg-white/20 text-white"
                    >
                      <SlidersHorizontal className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant={viewType === 'list' ? "default" : "ghost"} 
                      size="sm"
                      onClick={() => setViewType('list')}
                      className="h-9 w-9 p-0 bg-white/10 hover:bg-white/20 text-white"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                        <path fillRule="evenodd" d="M2 2.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5V3a.5.5 0 0 0-.5-.5H2zM3 3H2v1h1V3z"/>
                        <path d="M5 3.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM5.5 7a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 4a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9z"/>
                        <path fillRule="evenodd" d="M1.5 7a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5V7zM2 7h1v1H2V7zm0 3.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5H2zm1 .5H2v1h1v-1z"/>
                      </svg>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Статистический обзор */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-5 mb-8">
          <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-emerald-600 dark:text-emerald-400">Всего автомобилей</p>
                  <h4 className="text-3xl font-bold mt-1">{vehicles.length}</h4>
                </div>
                <div className="h-12 w-12 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center">
                  <Car className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-600 dark:text-blue-400">Активные</p>
                  <h4 className="text-3xl font-bold mt-1">{vehicles.filter(v => v.status === 'online').length}</h4>
                </div>
                <div className="h-12 w-12 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center">
                  <ShieldCheck className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-amber-50 to-yellow-50 dark:from-amber-950/30 dark:to-yellow-950/30 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-amber-600 dark:text-amber-400">На обслуживании</p>
                  <h4 className="text-3xl font-bold mt-1">{vehicles.filter(v => v.status === 'maintenance').length}</h4>
                </div>
                <div className="h-12 w-12 rounded-full bg-amber-100 dark:bg-amber-900/50 flex items-center justify-center">
                  <Gauge className="h-6 w-6 text-amber-600 dark:text-amber-400" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-50 to-fuchsia-50 dark:from-purple-950/30 dark:to-fuchsia-950/30 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-600 dark:text-purple-400">Последнее обновление</p>
                  <h4 className="text-xl font-bold mt-1">{new Date().toLocaleTimeString()}</h4>
                </div>
                <div className="h-12 w-12 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Основной контент */}
        <Card className="mb-8 border-0 shadow-md overflow-hidden">
          <CardHeader className="bg-gray-50 dark:bg-gray-800/50 border-b border-gray-100 dark:border-gray-700">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <CardTitle className="flex items-center text-xl gap-2">
                  <Sparkles className="h-5 w-5 text-amber-500" />
                  Ваша коллекция автомобилей
                </CardTitle>
                <CardDescription>
                  Управляйте всеми вашими транспортными средствами в одном месте
                </CardDescription>
              </div>
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <Button variant="outline" size="sm" className="gap-1">
                    <Filter className="h-4 w-4" />
                    <span>Фильтры</span>
                  </Button>
                </div>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-6">
            <Tabs defaultValue="vehicles" className="space-y-6">
              <TabsList className="w-full max-w-md mx-auto grid grid-cols-3 mb-6 bg-gray-100 dark:bg-gray-800 p-1">
                <TabsTrigger value="vehicles" className="rounded-md">Все ({vehicles.length})</TabsTrigger>
                <TabsTrigger value="active" className="rounded-md">Активные</TabsTrigger>
                <TabsTrigger value="maintenance" className="rounded-md">На обслуживании</TabsTrigger>
              </TabsList>
              
              <TabsContent value="vehicles" className="space-y-4 pt-2">
                {loading ? (
                  <div className="flex justify-center items-center py-20">
                    <div className="flex flex-col items-center">
                      <div className="animate-spin h-12 w-12 border-4 border-primary border-opacity-30 border-t-primary rounded-full mb-4"></div>
                      <p className="text-gray-500 dark:text-gray-400">Загрузка автомобилей...</p>
                    </div>
                  </div>
                ) : vehicles.length === 0 ? (
                  <div className="text-center py-16 px-4">
                    <div className="flex flex-col items-center justify-center">
                      <div className="bg-gray-100 dark:bg-gray-800 w-20 h-20 flex items-center justify-center rounded-full mb-6">
                        <Car className="h-10 w-10 text-gray-400 dark:text-gray-500" />
                      </div>
                      <h3 className="font-semibold text-gray-900 dark:text-white text-2xl mb-3">
                        У вас пока нет автомобилей
                      </h3>
                      <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-lg mx-auto">
                        Добавьте свой первый автомобиль для начала работы с системой мониторинга и управления. Это позволит вам отслеживать состояние автомобиля и управлять им удаленно.
                      </p>
                      <AddVehicleDialog onVehicleAdded={fetchVehicles} />
                    </div>
                  </div>
                ) : viewType === 'grid' ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {vehicles.map((vehicle) => (
                      <VehicleCard key={vehicle.id} vehicle={vehicle} onDelete={deleteVehicle} />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {vehicles.map((vehicle) => (
                      <VehicleListItem key={vehicle.id} vehicle={vehicle} onDelete={deleteVehicle} />
                    ))}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="active">
                <div className={viewType === 'grid' ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
                  {vehicles
                    .filter(v => v.status === 'online')
                    .map((vehicle) => (
                      viewType === 'grid' ? 
                        <VehicleCard key={vehicle.id} vehicle={vehicle} onDelete={deleteVehicle} /> : 
                        <VehicleListItem key={vehicle.id} vehicle={vehicle} onDelete={deleteVehicle} />
                    ))}
                  {vehicles.filter(v => v.status === 'online').length === 0 && (
                    <div className="col-span-full text-center py-12 bg-white dark:bg-gray-800 rounded-xl shadow-sm">
                      <p className="text-gray-500 dark:text-gray-400">Нет активных автомобилей</p>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="maintenance">
                <div className={viewType === 'grid' ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
                  {vehicles
                    .filter(v => v.status === 'maintenance')
                    .map((vehicle) => (
                      viewType === 'grid' ? 
                        <VehicleCard key={vehicle.id} vehicle={vehicle} onDelete={deleteVehicle} /> : 
                        <VehicleListItem key={vehicle.id} vehicle={vehicle} onDelete={deleteVehicle} />
                    ))}
                  {vehicles.filter(v => v.status === 'maintenance').length === 0 && (
                    <div className="col-span-full text-center py-12 bg-white dark:bg-gray-800 rounded-xl shadow-sm">
                      <p className="text-gray-500 dark:text-gray-400">Нет автомобилей на обслуживании</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
          
          <CardFooter className="bg-gray-50 dark:bg-gray-800/50 border-t border-gray-100 dark:border-gray-700 px-6 py-4">
            <div className="w-full flex items-center justify-between">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Всего автомобилей в системе: {vehicles.length}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Последнее обновление: {new Date().toLocaleTimeString()}
              </p>
            </div>
          </CardFooter>
        </Card>
      </div>
    </Layout>
  );
};

interface VehicleCardProps {
  vehicle: Vehicle;
  onDelete: (id: string) => Promise<void>;
}

const VehicleCard = ({ vehicle, onDelete }: VehicleCardProps) => {
  const getStatusBadge = () => {
    switch (vehicle.status) {
      case "online":
        return <Badge className="bg-green-500">В сети</Badge>;
      case "offline":
        return <Badge variant="outline" className="text-gray-500">Не в сети</Badge>;
      case "maintenance":
        return <Badge variant="secondary" className="bg-yellow-500 text-white">На обслуживании</Badge>;
      default:
        return <Badge variant="outline">Неизвестно</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  return (
    <Card className="overflow-hidden group hover:shadow-lg transition-all duration-300 hover:translate-y-[-5px] border border-gray-200 dark:border-gray-700">
      <div className="h-48 overflow-hidden relative">
        <img
          src={vehicle.image || "https://via.placeholder.com/400x200"}
          alt={`${vehicle.make || vehicle.model}`}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
        <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold">{vehicle.name}</h3>
            {getStatusBadge()}
          </div>
          <p className="text-sm text-gray-200">{vehicle.model}, {vehicle.year}</p>
        </div>
      </div>
      <CardContent className="p-5 space-y-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <CarFront className="h-5 w-5 text-blue-500" />
            <span className="font-medium">{vehicle.licensePlate}</span>
          </div>
          <div className="flex items-center space-x-2">
            <MapPin className="h-4 w-4 text-gray-500" />
            <span className="text-sm text-gray-500">Москва</span>
          </div>
        </div>
        
        <div className="space-y-3">
          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500 flex items-center">
                <Battery className="h-4 w-4 mr-1" /> Батарея
              </span>
              <span className="font-medium">{vehicle.batteryLevel}%</span>
            </div>
            <Progress 
              value={vehicle.batteryLevel} 
              className="h-2" 
            />
          </div>
          
          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500 flex items-center">
                <Fuel className="h-4 w-4 mr-1" /> Топливо
              </span>
              <span className="font-medium">{vehicle.fuelLevel}%</span>
            </div>
            <Progress 
              value={vehicle.fuelLevel} 
              className="h-2" 
            />
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-3 pt-2">
          <div className="flex flex-col">
            <span className="text-xs text-gray-500">Пробег</span>
            <span className="font-medium">{vehicle.mileage?.toLocaleString()} км</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs text-gray-500">Последнее ТО</span>
            <span className="font-medium truncate">
              {vehicle.lastService ? formatDate(vehicle.lastService.date).split(' ').slice(0, 2).join(' ') : "Нет данных"}
            </span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="bg-gray-50 dark:bg-gray-800/50 p-4 border-t border-gray-100 dark:border-gray-700">
        <div className="grid grid-cols-3 gap-2 w-full">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" className="w-full">
                <Trash2 className="h-4 w-4 mr-1" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Вы уверены?</AlertDialogTitle>
                <AlertDialogDescription>
                  Это действие нельзя отменить. Автомобиль "{vehicle.name}" будет удален из вашего списка.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Отмена</AlertDialogCancel>
                <AlertDialogAction onClick={() => onDelete(vehicle.id)}>Удалить</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          <Link to={`/vehicles/${vehicle.id}`} className="flex-1">
            <Button variant="outline" className="w-full">
              Подробнее
            </Button>
          </Link>
          <Link to={`/control/${vehicle.id}`} className="flex-1">
            <Button className="w-full">
              Управление
            </Button>
          </Link>
        </div>
      </CardFooter>
    </Card>
  );
};

const VehicleListItem = ({ vehicle, onDelete }: VehicleCardProps) => {
  const getStatusBadge = () => {
    switch (vehicle.status) {
      case "online":
        return <Badge className="bg-green-500">В сети</Badge>;
      case "offline":
        return <Badge variant="outline" className="text-gray-500">Не в сети</Badge>;
      case "maintenance":
        return <Badge variant="secondary" className="bg-yellow-500 text-white">На обслуживании</Badge>;
      default:
        return <Badge variant="outline">Неизвестно</Badge>;
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all duration-200 border border-gray-200 dark:border-gray-700">
      <div className="flex flex-col md:flex-row">
        <div className="md:w-1/4 lg:w-1/6 h-32 md:h-auto overflow-hidden">
          <img
            src={vehicle.image || "https://via.placeholder.com/400x200"}
            alt={`${vehicle.make || vehicle.model}`}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1 p-5">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <div className="flex items-center space-x-3">
                <h3 className="text-xl font-bold">{vehicle.name}</h3>
                {getStatusBadge()}
              </div>
              <p className="text-gray-600 dark:text-gray-300">{vehicle.model}, {vehicle.year}, {vehicle.color}</p>
              <p className="text-gray-500 text-sm mt-1">Гос. номер: {vehicle.licensePlate}</p>
            </div>
            
            <div className="mt-4 md:mt-0 flex flex-col md:items-end">
              <div className="flex items-center space-x-4 mb-3">
                <div className="flex items-center space-x-1">
                  <Battery className="h-4 w-4 text-blue-500" />
                  <span className="text-sm font-medium">{vehicle.batteryLevel}%</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Fuel className="h-4 w-4 text-blue-500" />
                  <span className="text-sm font-medium">{vehicle.fuelLevel}%</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Gauge className="h-4 w-4 text-blue-500" />
                  <span className="text-sm font-medium">{vehicle.mileage} км</span>
                </div>
              </div>
              
              <div className="flex space-x-3">
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm">
                      <Trash2 className="h-4 w-4 mr-1" />
                      Удалить
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Вы уверены?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Это действие нельзя отменить. Автомобиль "{vehicle.name}" будет удален из вашего списка.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Отмена</AlertDialogCancel>
                      <AlertDialogAction onClick={() => onDelete(vehicle.id)}>Удалить</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <Link to={`/vehicles/${vehicle.id}`}>
                  <Button variant="outline" size="sm">
                    Подробнее
                  </Button>
                </Link>
                <Link to={`/control/${vehicle.id}`}>
                  <Button size="sm">
                    Управление
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default VehiclesList;
